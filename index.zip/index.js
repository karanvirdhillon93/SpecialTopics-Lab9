exports.handler = async (event) => {
    console.log(JSON.stringify(event));

    const response ={
        statusCode: 200,
        body: event.body,
    };
    return response;
};